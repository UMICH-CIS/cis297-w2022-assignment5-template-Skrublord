﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BooksExamples
{
    /// <summary>
    /// Program housing
    /// </summary>
    class Program
    {
        /// <summary>
        /// hello world
        /// </summary>
        static void Main()
        {
            Console.WriteLine("Nathan Lipski was Here!");
        }
    }
}
